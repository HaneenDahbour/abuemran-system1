const { Telegraf, Markup } = require('telegraf');
const pool = require('./config/db');
const bot = new Telegraf(process.env.TELEGRAM_TOKEN);

// أمر البداية والربط
bot.start(async (ctx) => {
    ctx.reply('أهلاً بك في نظام أبو عمران الذكي. يرجى إرسال كود الربط الخاص بك لتفعيل الحساب.');
});

// التعامل مع طلبات "رصيدي"
bot.command('balance', async (ctx) => {
    const chatId = ctx.chat.id;
    const user = await pool.query("SELECT c.balance FROM clients c JOIN users u ON c.user_id = u.id WHERE u.telegram_chat_id = $1", [chatId]);

    if (user.rows.length > 0) {
        ctx.reply(`رصيدك الحالي هو: ${user.rows[0].balance} د.أ`);
    } else {
        ctx.reply('عذراً، هذا الحساب غير مربوط بالنظام.');
    }
});

// التعامل مع الدفع (إرسال صورة)
bot.on('photo', async (ctx) => {
    // 1. حفظ الصورة
    // 2. إرسال إشعار للمدير مع أزرار (Inline Buttons) للتأكيد
    ctx.reply('تم استلام صورة التحويل، جاري مراجعتها من قبل المحاسب... ⏳');

    // إرسال للمدير
    bot.telegram.sendMessage(process.env.MANAGER_CHAT_ID, `العميل أرسل وصل دفع، هل تؤكد؟`,
        Markup.inlineKeyboard([
            Markup.button.callback('✅ تأكيد الدفعة', 'confirm_pay'),
            Markup.button.callback('❌ رفض', 'reject_pay')
        ])
    );
});

bot.launch();