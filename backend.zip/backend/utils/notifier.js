const axios = require('axios');

const sendNotification = async (text) => {
    const token = process.env.TELEGRAM_TOKEN;
    const chatId = process.env.MANAGER_CHAT_ID;
    const url = `https://api.telegram.org/bot${token}/sendMessage`;

    try {
        await axios.post(url, { chat_id: chatId, text: text });
    } catch (error) {
        console.error("فشل إرسال التنبيه");
    }
};

module.exports = { sendNotification };