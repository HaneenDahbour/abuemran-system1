// جلب قائمة المستخدمين (للمدير فقط)
router.get('/users', verifyToken, async (req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: "غير مصرح لك" });

  try {
    const result = await pool.query("SELECT id, username, full_name, role, created_at FROM users");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: "خطأ في جلب المستخدمين" });
  }
});