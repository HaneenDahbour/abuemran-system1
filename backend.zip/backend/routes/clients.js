// backend/routes/clients.js

router.get('/', async (req, res) => {
  try {
    // نستخدم LEFT JOIN لجلب حالة التلغرام من جدول المستخدمين
    const query = `
            SELECT 
                c.*, 
                u.telegram_chat_id 
            FROM clients c
            LEFT JOIN users u ON c.user_id = u.id
            ORDER BY c.name ASC
        `;
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: "خطأ في جلب بيانات العملاء" });
  }
});