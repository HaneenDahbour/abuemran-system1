const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const { GoogleGenerativeAI } = require("@google/generative-ai");

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// ── المحرك التحليلي (للدردشة والتقارير) ─────────────────
router.post('/chat', async (req, res) => {
    const { message } = req.body;

    try {
        // جلب بيانات أكثر تفصيلاً ليكون الـ AI "خبيراً ماليًا"
        const stats = await pool.query(`
            SELECT 
                (SELECT SUM(balance) FROM clients) as total_debts,
                (SELECT COUNT(*) FROM checks WHERE status = 'pending') as pending_checks,
                (SELECT name FROM clients ORDER BY balance DESC LIMIT 3) as top_debtors
        `);

        const clients = await pool.query("SELECT name, balance, credit_limit FROM clients");

        const context = `
            أنت المساعد الذكي المتطور لنظام أبو عمران. 
            الحالة المالية الحالية:
            - إجمالي الديون في السوق: ${stats.rows[0].total_debts} د.أ
            - شيكات بانتظار التحصيل: ${stats.rows[0].pending_checks}
            - أكبر 3 مدينين: ${JSON.stringify(stats.rows[0].top_debtors)}
            بيانات العملاء: ${JSON.stringify(clients.rows)}

            مهمتك: 
            1. تحليل البيانات وتقديم نصائح للمدير (مثلاً: تنبيه إذا تجاوز عميل حده).
            2. الإجابة على استفسارات المحاسب عن الفواتير والشيكات.
            3. كتابة ردود مهنية ومختصرة جداً بالعربي.
        `;

        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
        const result = await model.generateContent([context, message]);

        res.json({ reply: result.response.text() });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "فشل الـ AI في تحليل البيانات" });
    }
});

// ── ميزة الـ OCR (قراءة صور الشيكات والفواتير) ──────────
// ملاحظة: ستحتاج لإرسال الصورة كـ Base64 من الـ Frontend
router.post('/read-image', async (req, res) => {
    const { imageBase64, type } = req.body; // type: 'check' or 'invoice'

    try {
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        const prompt = type === 'check'
            ? "اقرأ بيانات هذا الشيك واستخرج (المبلغ، التاريخ، رقم الشيك، اسم البنك) بصيغة JSON فقط."
            : "اقرأ هذه الفاتورة واستخرج (اسم المورد، التاريخ، المبلغ الصافي، رقم الفاتورة) بصيغة JSON فقط.";

        const result = await model.generateContent([
            prompt,
            { inlineData: { data: imageBase64, mimeType: "image/jpeg" } }
        ]);

        // تنظيف الاستجابة للحصول على JSON فقط
        const cleanJson = result.response.text().replace(/```json|```/g, "").trim();
        res.json(JSON.parse(cleanJson));

    } catch (err) {
        res.status(500).json({ error: "فشل الـ AI في قراءة الصورة" });
    }
});

module.exports = router;