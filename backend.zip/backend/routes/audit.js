const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const verifyToken = require('../middleware/auth');

// مسار الإحصائيات للوحة التحكم
router.get('/stats', verifyToken, async (req, res) => {
  try {
    const stats = await pool.query(`
            SELECT 
                (SELECT SUM(net_amount) FROM invoices) as total_sales,
                (SELECT SUM(balance) FROM clients) as total_debts,
                (SELECT COUNT(*) FROM checks WHERE due_date = CURRENT_DATE) as today_checks,
                (SELECT COUNT(*) FROM clients WHERE balance > 0) as active_clients
        `);
    res.json(stats.rows[0]);
  } catch (err) {
    res.status(500).json({ error: "خطأ في حساب الإحصائيات" });
  }
});

module.exports = router;