function openPaymentModal(cid, name) {
  showModal(`
        <h3>سند قبض لـ: ${name}</h3><br>
        <div class="fr"><label>المبلغ المستلم</label><input id="pay-amount" type="number"></div>
        <div class="fr"><label>طريقة الدفع</label>
            <select id="pay-method">
                <option value="نقدي">نقدي</option>
                <option value="تحويل بنكي">تحويل بنكي</option>
                <option value="شيك">شيك (يُسجل في قسم الشيكات)</option>
            </select>
        </div>
        <div class="fr"><label>ملاحظات</label><input id="pay-notes"></div>
        <button class="btn btn-s" style="width:100%" onclick="savePayment(${cid})">تأكيد واستلام المبلغ</button>
    `);
}

async function savePayment(cid) {
  const body = {
    client_id: cid,
    amount: document.getElementById('pay-amount').value,
    payment_method: document.getElementById('pay-method').value,
    notes: document.getElementById('pay-notes').value
  };
  await fetch(`${API_BASE}/payments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
    body: JSON.stringify(body)
  });
  closeModal();
  loadSection('clients'); // لتحديث الرصيد فوراً في الواجهة
}